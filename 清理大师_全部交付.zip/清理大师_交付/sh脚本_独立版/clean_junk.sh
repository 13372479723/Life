#!/system/bin/sh
# =====================================================================
#  清理大师 · 清理垃圾（独立版，带白名单）
#  功能：清理可见垃圾目录 + (Root)逐应用清缓存
#  白名单：应用(包名) + 文件夹(路径)，支持从列表勾选/手动添加
#  特性：彩色 ASCII 进度条仪表盘、普通/Root 双模式
# =====================================================================

# -------- 配置/白名单 --------
CFG_DIR="${HOME:-/sdcard}/.clean_master"
WL_APP="$CFG_DIR/whitelist_app.txt"
WL_PATH="$CFG_DIR/whitelist_path.txt"
mkdir -p "$CFG_DIR" 2>/dev/null
if [ ! -f "$WL_PATH" ]; then
  cat > "$WL_PATH" <<EOF
/storage/emulated/0/DCIM
/storage/emulated/0/Pictures
/storage/emulated/0/Download
/storage/emulated/0/Documents
EOF
fi
[ -f "$WL_APP" ] || : > "$WL_APP"

ESC=$(printf '\033')
C_RESET="${ESC}[0m";  C_BOLD="${ESC}[1m"
C_CYAN="${ESC}[36m";  C_GREEN="${ESC}[32m"; C_YELLOW="${ESC}[33m"
C_RED="${ESC}[31m";   C_BLUE="${ESC}[34m";  C_MAGENTA="${ESC}[35m"; C_GRAY="${ESC}[90m"

MODE="normal"
has_root() {
  for p in /system/bin/su /system/xbin/su /sbin/su /su/bin/su /vendor/bin/su; do
    [ -x "$p" ] && return 0
  done
  command -v su >/dev/null 2>&1 && return 0
  return 1
}
RUN() { if [ "$MODE" = "root" ]; then su -c "$*" 2>/dev/null; else sh -c "$*" 2>/dev/null; fi; }
toggle_mode() {
  if [ "$MODE" = "root" ]; then MODE="normal"
  elif has_root && su -c "id" 2>/dev/null | grep -q "uid=0"; then MODE="root"
  else printf "  %s未获取到 root 权限%s\n" "$C_RED" "$C_RESET"; sleep 2; fi
}
human() {
  awk -v b="$1" 'BEGIN{s="B KB MB GB TB";n=split(s,u," ");v=b;i=1;while(v>=1024&&i<n){v/=1024;i++}printf("%.2f%s",v,u[i])}'
}
draw_bar() {
  pct=$1; label=$2
  [ "$pct" -gt 100 ] && pct=100; [ "$pct" -lt 0 ] && pct=0
  width=30; filled=$(( pct*width/100 )); empty=$(( width-filled ))
  if [ "$pct" -lt 40 ]; then col=$C_RED; elif [ "$pct" -lt 75 ]; then col=$C_YELLOW; else col=$C_GREEN; fi
  bar=""; i=0; while [ $i -lt $filled ]; do bar="${bar}█"; i=$((i+1)); done
  j=0; while [ $j -lt $empty ]; do bar="${bar}░"; j=$((j+1)); done
  printf "\r  %s[%s%s%s] %s%3d%%%s  %-28.28s" "$C_BOLD" "$col" "$bar" "$C_RESET$C_BOLD" "$col" "$pct" "$C_RESET" "$label"
}
line() { printf "%s%s%s\n" "$C_GRAY" "────────────────────────────────────────────────" "$C_RESET"; }

dashboard() {
  clear 2>/dev/null
  printf "%s%s   🧹  清 理 垃 圾%s   [模式: %s]\n" "$C_BOLD" "$C_CYAN" "$C_RESET" \
    "$( [ "$MODE" = root ] && printf "%sROOT%s" "$C_GREEN" "$C_RESET" || printf "%s普通%s" "$C_YELLOW" "$C_RESET" )"
  line
  read_st=$(df /data 2>/dev/null | awk 'NR==2{print $2" "$3}')
  st=$(echo "$read_st" | awk '{print $1}'); su_=$(echo "$read_st" | awk '{print $2}')
  if [ -n "$st" ] && [ "$st" -gt 0 ] 2>/dev/null; then
    p=$(( su_*100/st ))
    printf "  %s存储%s 已用 %s / 总 %s\n" "$C_BOLD" "$C_RESET" "$(human $((su_*1024)))" "$(human $((st*1024)))"
    draw_bar "$p" "internal storage"; printf "\n"
  fi
  if [ -r /proc/meminfo ]; then
    mt=$(awk '/MemTotal/{print $2}' /proc/meminfo)
    ma=$(awk '/MemAvailable/{print $2}' /proc/meminfo); [ -z "$ma" ] && ma=$(awk '/MemFree/{print $2}' /proc/meminfo)
    mu=$(( mt-ma )); mp=$(( mu*100/mt ))
    printf "  %s内存%s 已用 %s / 总 %s\n" "$C_BOLD" "$C_RESET" "$(human $((mu*1024)))" "$(human $((mt*1024)))"
    draw_bar "$mp" "RAM"; printf "\n"
  fi
  line
}

# -------- 白名单判断 --------
in_path_whitelist() {
  while IFS= read -r w; do
    [ -z "$w" ] && continue
    case "$1" in "$w"*) return 0;; esac
  done < "$WL_PATH"
  return 1
}
in_app_whitelist() { grep -qxF "$1" "$WL_APP" 2>/dev/null; }

# -------- 清理 --------
clean_junk() {
  dashboard
  printf "  %s清理垃圾%s  (应用白名单 %s 条 / 文件夹白名单 %s 条)\n" \
    "$C_BOLD$C_BLUE" "$C_RESET" "$(grep -c . "$WL_APP" 2>/dev/null)" "$(grep -c . "$WL_PATH" 2>/dev/null)"
  line
  freed=0; cnt=0; sd="/storage/emulated/0"
  dir_targets="$sd/.thumbnails $sd/DCIM/.thumbnails $sd/Android/.Trash $sd/LOST.DIR $sd/.temp $sd/temp $sd/.cache"
  set -- $dir_targets; dtot=$#
  if [ "$MODE" = "root" ]; then
    apps=$(su -c "pm list packages" 2>/dev/null | sed 's/package://'); atot=$(echo "$apps" | grep -c .)
  else apps=""; atot=0; fi
  total=$(( dtot+atot )); [ "$total" -eq 0 ] && total=1; step=0

  for t in $dir_targets; do
    step=$((step+1)); pct=$(( step*100/total )); draw_bar "$pct" "目录: $(basename "$t")"
    in_path_whitelist "$t" && continue
    if [ -d "$t" ]; then
      sz=$(RUN "du -sk '$t'" | awk '{print $1}'); [ -z "$sz" ] && sz=0
      RUN "rm -rf '$t'"; freed=$(( freed+sz*1024 )); cnt=$((cnt+1))
    fi
  done

  if [ "$MODE" = "root" ]; then
    tmp_apps="$CFG_DIR/.apps.$$"; echo "$apps" > "$tmp_apps"
    while IFS= read -r p; do
      [ -z "$p" ] && continue
      step=$((step+1)); pct=$(( step*100/total )); draw_bar "$pct" "缓存: $p"
      in_app_whitelist "$p" && continue
      for sub in cache code_cache; do
        d="/data/data/$p/$sub"; in_path_whitelist "$d" && continue
        sz=$(su -c "du -sk '$d' 2>/dev/null" | awk '{print $1}'); [ -z "$sz" ] && sz=0
        if [ "$sz" -gt 0 ]; then su -c "rm -rf '$d'" 2>/dev/null; freed=$(( freed+sz*1024 )); cnt=$((cnt+1)); fi
      done
    done < "$tmp_apps"
    rm -f "$tmp_apps"
  fi

  draw_bar 100 "完成"; printf "\n"
  printf "  %s✔ 清理完成，共 %s 项，释放约 %s%s\n" "$C_GREEN" "$cnt" "$(human $freed)" "$C_RESET"
  printf "\n  回车继续..."; read _
}

# -------- 从列表勾选应用 --------
pick_app_to_whitelist() {
  dashboard
  printf "  %s选择应用加入清理白名单%s（已在名单标 %s✔%s）\n" "$C_BOLD$C_MAGENTA" "$C_RESET" "$C_GREEN" "$C_RESET"; line
  tmp_list="$CFG_DIR/.applist.$$"
  RUN "pm list packages -3" | sed 's/package://' | sort > "$tmp_list"
  [ -s "$tmp_list" ] || pm list packages -3 2>/dev/null | sed 's/package://' | sort > "$tmp_list"
  if [ ! -s "$tmp_list" ]; then
    printf "  %s未获取到应用列表%s\n" "$C_RED" "$C_RESET"; rm -f "$tmp_list"; printf "\n  回车返回..."; read _; return
  fi
  idx=0
  while IFS= read -r p; do
    [ -z "$p" ] && continue; idx=$((idx+1))
    if grep -qxF "$p" "$WL_APP" 2>/dev/null; then mark="$C_GREEN✔$C_RESET"; else mark=" "; fi
    printf "  %s%3d%s [%s] %s\n" "$C_GRAY" "$idx" "$C_RESET" "$mark" "$p"
  done < "$tmp_list"
  line
  printf "  输入编号切换勾选(空格分隔多个，如 1 3 5)，回车返回: "; read nums
  [ -z "$nums" ] && { rm -f "$tmp_list"; return; }
  for n in $nums; do
    pkg=$(sed -n "${n}p" "$tmp_list"); [ -z "$pkg" ] && continue
    if grep -qxF "$pkg" "$WL_APP" 2>/dev/null; then
      grep -vxF "$pkg" "$WL_APP" > "$WL_APP.tmp" && mv "$WL_APP.tmp" "$WL_APP"
      printf "  %s- 移出白名单: %s%s\n" "$C_YELLOW" "$pkg" "$C_RESET"
    else
      echo "$pkg" >> "$WL_APP"; printf "  %s+ 加入白名单: %s%s\n" "$C_GREEN" "$pkg" "$C_RESET"
    fi
  done
  rm -f "$tmp_list"; printf "\n  回车返回..."; read _
}

# -------- 白名单管理菜单 --------
whitelist_menu() {
  while :; do
    dashboard
    printf "  %s清理白名单管理%s\n" "$C_BOLD$C_MAGENTA" "$C_RESET"; line
    printf "  %s应用白名单 (%s 条):%s\n" "$C_BOLD" "$(grep -c . "$WL_APP" 2>/dev/null)" "$C_RESET"
    nl -ba "$WL_APP" 2>/dev/null | sed 's/^/    /'
    printf "  %s文件夹白名单 (%s 条):%s\n" "$C_BOLD" "$(grep -c . "$WL_PATH" 2>/dev/null)" "$C_RESET"
    nl -ba "$WL_PATH" 2>/dev/null | sed 's/^/    /'
    line
    printf "  %s1%s)从列表勾选应用  %s2%s)手输包名加应用  %s3%s)删应用\n" "$C_GREEN" "$C_RESET" "$C_GREEN" "$C_RESET" "$C_RED" "$C_RESET"
    printf "  %s4%s)加文件夹  %s5%s)删文件夹  %s0%s)返回 : " "$C_GREEN" "$C_RESET" "$C_RED" "$C_RESET" "$C_GRAY" "$C_RESET"
    read c
    case "$c" in
      1) pick_app_to_whitelist ;;
      2) printf "  输入应用包名: "; read v
         [ -n "$v" ] && ! grep -qxF "$v" "$WL_APP" && echo "$v" >> "$WL_APP" ;;
      3) printf "  输入要删除的应用包名: "; read v
         [ -n "$v" ] && grep -vxF "$v" "$WL_APP" > "$WL_APP.tmp" && mv "$WL_APP.tmp" "$WL_APP" ;;
      4) printf "  输入文件夹绝对路径(/开头): "; read v
         case "$v" in /*) grep -qxF "$v" "$WL_PATH" || echo "$v" >> "$WL_PATH";;
            *) printf "  %s路径需以 / 开头%s\n" "$C_RED" "$C_RESET"; sleep 1;; esac ;;
      5) printf "  输入要删除的文件夹路径: "; read v
         [ -n "$v" ] && grep -vxF "$v" "$WL_PATH" > "$WL_PATH.tmp" && mv "$WL_PATH.tmp" "$WL_PATH" ;;
      0) return ;;
    esac
  done
}

has_root && printf "%s检测到 root，按 m 可切换 ROOT 模式（逐应用深清缓存）%s\n" "$C_GREEN" "$C_RESET" && sleep 1
while :; do
  dashboard
  printf "  %s1%s)开始清理  %s2%s)白名单管理\n" "$C_GREEN" "$C_RESET" "$C_MAGENTA" "$C_RESET"
  printf "  %sm%s)切换模式(当前 %s)  %s0%s)退出 : " \
    "$C_YELLOW" "$C_RESET" "$( [ "$MODE" = root ] && echo ROOT || echo 普通 )" "$C_GRAY" "$C_RESET"
  read ch
  case "$ch" in
    1) clean_junk ;;
    2) whitelist_menu ;;
    m|M) toggle_mode ;;
    0) clear 2>/dev/null; exit 0 ;;
  esac
done
