#!/system/bin/sh
# =====================================================================
#  清理大师 · 吃掉内存（独立版）
#  功能：释放运行内存（sync + drop_caches + 回收应用内存）
#  特性：彩色 ASCII 进度条仪表盘、普通/Root 双模式
# =====================================================================

ESC=$(printf '\033')
C_RESET="${ESC}[0m";  C_BOLD="${ESC}[1m"
C_CYAN="${ESC}[36m";  C_GREEN="${ESC}[32m"; C_YELLOW="${ESC}[33m"
C_RED="${ESC}[31m";   C_BLUE="${ESC}[34m";  C_GRAY="${ESC}[90m"

MODE="normal"
has_root() {
  for p in /system/bin/su /system/xbin/su /sbin/su /su/bin/su /vendor/bin/su; do
    [ -x "$p" ] && return 0
  done
  command -v su >/dev/null 2>&1 && return 0
  return 1
}
toggle_mode() {
  if [ "$MODE" = "root" ]; then MODE="normal"
  elif has_root && su -c "id" 2>/dev/null | grep -q "uid=0"; then MODE="root"
  else printf "  %s未获取到 root 权限%s\n" "$C_RED" "$C_RESET"; sleep 2; fi
}
human() {
  awk -v b="$1" 'BEGIN{s="B KB MB GB TB";n=split(s,u," ");v=b;i=1;while(v>=1024&&i<n){v/=1024;i++}printf("%.2f%s",v,u[i])}'
}
draw_bar() {
  pct=$1; label=$2
  [ "$pct" -gt 100 ] && pct=100; [ "$pct" -lt 0 ] && pct=0
  width=30; filled=$(( pct*width/100 )); empty=$(( width-filled ))
  if [ "$pct" -lt 40 ]; then col=$C_RED; elif [ "$pct" -lt 75 ]; then col=$C_YELLOW; else col=$C_GREEN; fi
  bar=""; i=0; while [ $i -lt $filled ]; do bar="${bar}█"; i=$((i+1)); done
  j=0; while [ $j -lt $empty ]; do bar="${bar}░"; j=$((j+1)); done
  printf "\r  %s[%s%s%s] %s%3d%%%s  %-28.28s" "$C_BOLD" "$col" "$bar" "$C_RESET$C_BOLD" "$col" "$pct" "$C_RESET" "$label"
}
line() { printf "%s%s%s\n" "$C_GRAY" "────────────────────────────────────────────────" "$C_RESET"; }

dashboard() {
  clear 2>/dev/null
  printf "%s%s   🧠  吃 掉 内 存%s   [模式: %s]\n" "$C_BOLD" "$C_CYAN" "$C_RESET" \
    "$( [ "$MODE" = root ] && printf "%sROOT%s" "$C_GREEN" "$C_RESET" || printf "%s普通%s" "$C_YELLOW" "$C_RESET" )"
  line
  read_st=$(df /data 2>/dev/null | awk 'NR==2{print $2" "$3}')
  st=$(echo "$read_st" | awk '{print $1}'); su_=$(echo "$read_st" | awk '{print $2}')
  if [ -n "$st" ] && [ "$st" -gt 0 ] 2>/dev/null; then
    p=$(( su_*100/st ))
    printf "  %s存储%s 已用 %s / 总 %s\n" "$C_BOLD" "$C_RESET" "$(human $((su_*1024)))" "$(human $((st*1024)))"
    draw_bar "$p" "internal storage"; printf "\n"
  fi
  if [ -r /proc/meminfo ]; then
    mt=$(awk '/MemTotal/{print $2}' /proc/meminfo)
    ma=$(awk '/MemAvailable/{print $2}' /proc/meminfo); [ -z "$ma" ] && ma=$(awk '/MemFree/{print $2}' /proc/meminfo)
    mu=$(( mt-ma )); mp=$(( mu*100/mt ))
    printf "  %s内存%s 已用 %s / 总 %s\n" "$C_BOLD" "$C_RESET" "$(human $((mu*1024)))" "$(human $((mt*1024)))"
    draw_bar "$mp" "RAM"; printf "\n"
  fi
  line
}

eat_memory() {
  dashboard
  printf "  %s吃掉内存%s\n" "$C_BOLD$C_BLUE" "$C_RESET"; line
  before=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
  draw_bar 15 "同步文件系统 sync"
  if [ "$MODE" = "root" ]; then su -c "sync" 2>/dev/null; else sync 2>/dev/null; fi
  draw_bar 45 "释放页缓存 drop_caches"
  if [ "$MODE" = "root" ]; then
    su -c "echo 3 > /proc/sys/vm/drop_caches" 2>/dev/null
    draw_bar 75 "回收应用内存 am kill-all"
    su -c "am kill-all" 2>/dev/null
  else
    for p in $(pm list packages -3 2>/dev/null | sed 's/package://'); do am kill "$p" 2>/dev/null; done
    draw_bar 75 "请求系统回收内存"
  fi
  draw_bar 100 "完成"; printf "\n"
  after=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
  freed=$(( (after-before)*1024 )); [ "$freed" -lt 0 ] && freed=0
  printf "  %s✔ 本次释放运行内存约 %s%s\n" "$C_GREEN" "$(human $freed)" "$C_RESET"
  printf "\n  回车继续..."; read _
}

has_root && printf "%s检测到 root，按 m 可切换 ROOT 模式（释放更彻底）%s\n" "$C_GREEN" "$C_RESET" && sleep 1
while :; do
  eat_memory
  printf "  %sm%s)切换模式(当前 %s)  %s0%s)退出  其它)再释放一次 : " \
    "$C_YELLOW" "$C_RESET" "$( [ "$MODE" = root ] && echo ROOT || echo 普通 )" "$C_GRAY" "$C_RESET"
  read k
  case "$k" in m|M) toggle_mode ;; 0) clear 2>/dev/null; exit 0 ;; esac
done
