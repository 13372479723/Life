package com.clean.master.core

import android.content.Context

/** 设置 / 模式 / 白名单 的本地持久化。 */
object Prefs {
    private const val FILE = "clean_master_prefs"
    private const val KEY_MODE = "run_mode"               // 0=普通 1=root
    private const val KEY_WHITELIST_APP = "wl_app"        // 杀后台/吃内存 白名单(包名)
    private const val KEY_WHITELIST_PATH = "wl_path"      // 清理垃圾 文件夹白名单(路径)
    private const val KEY_WHITELIST_CLEAN_APP = "wl_clean_app" // 清理垃圾 应用白名单(包名，跳过其缓存)

    const val MODE_NORMAL = 0
    const val MODE_ROOT = 1

    private fun sp(ctx: Context) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getMode(ctx: Context): Int = sp(ctx).getInt(KEY_MODE, MODE_NORMAL)
    fun setMode(ctx: Context, mode: Int) = sp(ctx).edit().putInt(KEY_MODE, mode).apply()
    fun isRoot(ctx: Context) = getMode(ctx) == MODE_ROOT

    // ---- 应用白名单 ----
    fun getAppWhiteList(ctx: Context): MutableSet<String> =
        sp(ctx).getStringSet(KEY_WHITELIST_APP, emptySet())!!.toMutableSet()

    fun setAppWhiteList(ctx: Context, set: Set<String>) =
        sp(ctx).edit().putStringSet(KEY_WHITELIST_APP, set).apply()

    fun isAppWhiteListed(ctx: Context, pkg: String) = getAppWhiteList(ctx).contains(pkg)

    // ---- 清理垃圾：文件夹白名单（命中目录会被跳过，不删除）----
    fun getPathWhiteList(ctx: Context): MutableSet<String> =
        sp(ctx).getStringSet(KEY_WHITELIST_PATH, defaultPathWhiteList())!!.toMutableSet()

    fun setPathWhiteList(ctx: Context, set: Set<String>) =
        sp(ctx).edit().putStringSet(KEY_WHITELIST_PATH, set).apply()

    fun addPath(ctx: Context, path: String) {
        val s = getPathWhiteList(ctx); s.add(path); setPathWhiteList(ctx, s)
    }

    fun removePath(ctx: Context, path: String) {
        val s = getPathWhiteList(ctx); s.remove(path); setPathWhiteList(ctx, s)
    }

    // ---- 清理垃圾：应用白名单（命中应用的缓存会被跳过，不清理）----
    fun getCleanAppWhiteList(ctx: Context): MutableSet<String> =
        sp(ctx).getStringSet(KEY_WHITELIST_CLEAN_APP, emptySet())!!.toMutableSet()

    fun setCleanAppWhiteList(ctx: Context, set: Set<String>) =
        sp(ctx).edit().putStringSet(KEY_WHITELIST_CLEAN_APP, set).apply()

    fun isCleanAppWhiteListed(ctx: Context, pkg: String) =
        getCleanAppWhiteList(ctx).contains(pkg)

    /** 默认保护一些常见重要目录，避免误删。 */
    private fun defaultPathWhiteList(): Set<String> = setOf(
        "/storage/emulated/0/DCIM",
        "/storage/emulated/0/Pictures",
        "/storage/emulated/0/Download",
        "/storage/emulated/0/Documents"
    )
}
