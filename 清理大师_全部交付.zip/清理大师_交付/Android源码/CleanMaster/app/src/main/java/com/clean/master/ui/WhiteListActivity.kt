package com.clean.master.ui

import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.clean.master.R
import com.clean.master.core.Prefs
import com.clean.master.databinding.ActivityWhitelistBinding
import com.clean.master.databinding.ItemWhitelistBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 白名单管理，分三类：
 *  TAB_KILL  保护应用  -> 「杀死后台 / 吃掉内存」时跳过这些应用
 *  TAB_CLEAN_APP 清理-保护应用 -> 「清理垃圾」时跳过这些应用的缓存
 *  TAB_CLEAN_PATH 清理-保护文件夹 -> 「清理垃圾」时跳过这些目录（支持手动添加）
 */
class WhiteListActivity : AppCompatActivity() {

    private lateinit var b: ActivityWhitelistBinding
    private val adapter = WhiteAdapter { row -> toggle(row) }

    private val rows = mutableListOf<Row>()
    private var tab = TAB_KILL

    companion object {
        const val TAB_KILL = 0
        const val TAB_CLEAN_APP = 1
        const val TAB_CLEAN_PATH = 2
    }

    data class Row(
        val title: String,
        val sub: String,
        val key: String,      // 应用为包名，文件夹为目录路径
        var checked: Boolean,
        val isApp: Boolean
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityWhitelistBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.rvWhite.layoutManager = LinearLayoutManager(this)
        b.rvWhite.adapter = adapter

        b.tabKill.setOnClickListener { switchTab(TAB_KILL) }
        b.tabCleanApp.setOnClickListener { switchTab(TAB_CLEAN_APP) }
        b.tabCleanPath.setOnClickListener { switchTab(TAB_CLEAN_PATH) }
        b.btnAddPath.setOnClickListener { addCustomPath() }

        switchTab(TAB_KILL)
    }

    private fun switchTab(t: Int) {
        tab = t
        b.tabKill.isSelected = t == TAB_KILL
        b.tabCleanApp.isSelected = t == TAB_CLEAN_APP
        b.tabCleanPath.isSelected = t == TAB_CLEAN_PATH
        b.btnAddPath.visibility = if (t == TAB_CLEAN_PATH) View.VISIBLE else View.GONE
        when (t) {
            TAB_KILL -> loadApps(forClean = false,
                hint = "勾选的应用在「杀死后台 / 吃掉内存」时会被保留，不会被结束。")
            TAB_CLEAN_APP -> loadApps(forClean = true,
                hint = "勾选的应用在「清理垃圾」时会被跳过，不清理其缓存。")
            TAB_CLEAN_PATH -> loadPaths()
        }
    }

    private fun loadApps(forClean: Boolean, hint: String) {
        b.tvHint.text = hint
        lifecycleScope.launch {
            val white = if (forClean) Prefs.getCleanAppWhiteList(this@WhiteListActivity)
            else Prefs.getAppWhiteList(this@WhiteListActivity)
            val list = withContext(Dispatchers.IO) {
                packageManager.getInstalledApplications(0)
                    .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                    .filter { it.packageName != packageName }
                    .map {
                        val label = try {
                            packageManager.getApplicationLabel(it).toString()
                        } catch (e: Exception) {
                            it.packageName
                        }
                        Row(label, it.packageName, it.packageName,
                            white.contains(it.packageName), true)
                    }
                    .sortedBy { it.title }
            }
            rows.clear(); rows.addAll(list)
            adapter.submit(rows)
        }
    }

    private fun loadPaths() {
        b.tvHint.text = "勾选的文件夹在「清理垃圾」时会被跳过，避免误删重要文件。点右上「添加目录」可手动添加。"
        val white = Prefs.getPathWhiteList(this)
        val candidates = linkedSetOf(
            "/storage/emulated/0/DCIM",
            "/storage/emulated/0/Pictures",
            "/storage/emulated/0/Download",
            "/storage/emulated/0/Documents",
            "/storage/emulated/0/Movies",
            "/storage/emulated/0/Music"
        )
        candidates.addAll(white)
        rows.clear()
        candidates.forEach {
            rows.add(Row(it.substringAfterLast('/'), it, it, white.contains(it), false))
        }
        adapter.submit(rows)
    }

    private fun toggle(row: Row) {
        row.checked = !row.checked
        when (tab) {
            TAB_KILL -> {
                val set = Prefs.getAppWhiteList(this)
                if (row.checked) set.add(row.key) else set.remove(row.key)
                Prefs.setAppWhiteList(this, set)
            }
            TAB_CLEAN_APP -> {
                val set = Prefs.getCleanAppWhiteList(this)
                if (row.checked) set.add(row.key) else set.remove(row.key)
                Prefs.setCleanAppWhiteList(this, set)
            }
            TAB_CLEAN_PATH -> {
                val set = Prefs.getPathWhiteList(this)
                if (row.checked) set.add(row.key) else set.remove(row.key)
                Prefs.setPathWhiteList(this, set)
            }
        }
        adapter.notifyDataSetChanged()
    }

    private fun addCustomPath() {
        val input = android.widget.EditText(this).apply {
            hint = "例如 /storage/emulated/0/MyFolder"
        }
        AlertDialog.Builder(this)
            .setTitle("添加保护文件夹")
            .setView(input)
            .setPositiveButton("添加") { _, _ ->
                val p = input.text.toString().trim().trimEnd('/')
                if (p.startsWith("/")) {
                    Prefs.addPath(this, p)
                    loadPaths()
                } else {
                    toast("请输入以 / 开头的绝对路径")
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun toast(msg: String) =
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()

    // ---------------- Adapter ----------------
    class WhiteAdapter(val onToggle: (Row) -> Unit) :
        RecyclerView.Adapter<WhiteAdapter.VH>() {

        private val data = mutableListOf<Row>()

        fun submit(list: List<Row>) {
            data.clear(); data.addAll(list); notifyDataSetChanged()
        }

        class VH(val v: ItemWhitelistBinding) : RecyclerView.ViewHolder(v.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = ItemWhitelistBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return VH(v)
        }

        override fun getItemCount() = data.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val row = data[position]
            holder.v.wName.text = row.title
            holder.v.wSub.text = row.sub
            holder.v.wSwitch.isChecked = row.checked
            if (row.isApp) {
                try {
                    holder.v.wIcon.setImageDrawable(
                        holder.itemView.context.packageManager.getApplicationIcon(row.key)
                    )
                } catch (e: Exception) {
                    holder.v.wIcon.setImageResource(R.drawable.ic_app)
                }
            } else {
                holder.v.wIcon.setImageResource(R.drawable.ic_junk)
            }
            holder.itemView.setOnClickListener { onToggle(row) }
        }
    }
}
