package com.clean.master.core

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import java.io.File

/**
 * 四大功能的核心引擎。
 * 每个方法都通过 progress 回调实时上报进度(0..100)与当前处理项，供 UI 进度条使用。
 */
class Cleaner(private val ctx: Context) {

    private val isRoot get() = Prefs.isRoot(ctx)

    interface Progress {
        fun onProgress(percent: Int, label: String)
        fun onDone(summary: String)
    }

    // ============================================================
    // 功能一：杀死后台
    // ============================================================
    fun killBackground(cb: Progress) {
        val pm = ctx.packageManager
        val whitelist = Prefs.getAppWhiteList(ctx)
        // 取出所有第三方且正在/可能运行的应用
        val apps = pm.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .filter { it.packageName != ctx.packageName }
            .filter { !whitelist.contains(it.packageName) }

        var killed = 0
        val total = apps.size.coerceAtLeast(1)
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

        apps.forEachIndexed { i, app ->
            val name = labelOf(pm, app)
            if (isRoot) {
                // root: am force-stop 彻底杀死
                val r = ShellUtils.exec("am force-stop ${app.packageName}", root = true, timeoutMs = 8000)
                if (r.ok) killed++
            } else {
                // 普通: killBackgroundProcesses（仅能杀后台缓存进程）
                try {
                    am.killBackgroundProcesses(app.packageName)
                    killed++
                } catch (_: Exception) {}
            }
            cb.onProgress((i + 1) * 100 / total, "正在结束：$name")
        }
        cb.onDone("已结束 $killed 个应用的后台进程")
    }

    // ============================================================
    // 功能二：吃掉内存（释放运行内存）
    // ============================================================
    fun eatMemory(cb: Progress) {
        val before = SystemInfo.ram(ctx).freeBytes
        if (isRoot) {
            cb.onProgress(20, "同步文件系统…")
            ShellUtils.exec("sync", root = true)
            cb.onProgress(50, "释放页缓存(drop_caches)…")
            // 1=pagecache 2=dentries+inodes 3=全部
            ShellUtils.exec("echo 3 > /proc/sys/vm/drop_caches", root = true)
            cb.onProgress(80, "回收应用内存…")
            ShellUtils.exec("am kill-all", root = true, timeoutMs = 8000)
        } else {
            // 普通模式：杀后台 + 触发 GC 让系统回收
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val pm = ctx.packageManager
            val whitelist = Prefs.getAppWhiteList(ctx)
            val apps = pm.getInstalledApplications(0)
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                .filter { it.packageName != ctx.packageName && !whitelist.contains(it.packageName) }
            apps.forEachIndexed { i, app ->
                try { am.killBackgroundProcesses(app.packageName) } catch (_: Exception) {}
                cb.onProgress(20 + i * 60 / apps.size.coerceAtLeast(1), "回收：${labelOf(pm, app)}")
            }
            cb.onProgress(90, "请求系统回收内存…")
            System.gc()
        }
        cb.onProgress(100, "完成")
        val after = SystemInfo.ram(ctx).freeBytes
        val freed = (after - before).coerceAtLeast(0)
        cb.onDone("本次释放运行内存约 ${SystemInfo.formatSize(freed)}")
    }

    // ============================================================
    // 功能三：清理垃圾（带路径白名单）
    // ============================================================
    fun cleanJunk(cb: Progress) {
        val whitePaths = Prefs.getPathWhiteList(ctx)       // 文件夹白名单
        val whiteApps = Prefs.getCleanAppWhiteList(ctx)    // 应用白名单（跳过其缓存）
        var freedBytes = 0L
        var fileCount = 0

        // 第一阶段：外置存储上的可见垃圾目录（普通/root 均处理）
        val sdcard = "/storage/emulated/0"
        val visibleTargets = listOf(
            "$sdcard/.thumbnails",
            "$sdcard/DCIM/.thumbnails",
            "$sdcard/Android/.Trash",
            "$sdcard/LOST.DIR",
            "$sdcard/.temp",
            "$sdcard/temp",
            "$sdcard/.cache"
        )

        // root 模式额外清理的系统级目录（不含逐应用缓存，缓存在第二阶段处理）
        val rootSysTargets = listOf(
            "/data/system/dropbox",
            "/data/anr",
            "/data/tombstones"
        )

        val dirTargets = if (isRoot) visibleTargets + rootSysTargets else visibleTargets

        // 估算总步数：目录 + （root 下逐应用缓存）
        val cacheApps: List<ApplicationInfo> =
            if (isRoot) {
                ctx.packageManager.getInstalledApplications(0)
                    .filter { !whiteApps.contains(it.packageName) }
            } else emptyList()
        val total = (dirTargets.size + cacheApps.size).coerceAtLeast(1)
        var step = 0

        // ---- 阶段一：目录清理 ----
        dirTargets.forEach { t ->
            step++
            cb.onProgress(step * 100 / total, "扫描目录：$t")
            // 命中文件夹白名单则跳过
            if (whitePaths.any { t.startsWith(it) }) return@forEach
            val dir = File(t)
            if (dir.exists()) {
                val (sz, cnt) = dirSizeAndCount(dir)
                deleteRecursive(dir, whitePaths)
                freedBytes += sz
                fileCount += cnt
            }
        }

        // ---- 阶段二：root 下逐应用清理 /data/data/<pkg>/cache（跳过应用白名单）----
        if (isRoot) {
            val pm = ctx.packageManager
            cacheApps.forEach { app ->
                step++
                cb.onProgress(step * 100 / total, "清理缓存：${labelOf(pm, app)}")
                val pkg = app.packageName
                // 命中应用白名单则跳过（双保险，cacheApps 已过滤）
                if (whiteApps.contains(pkg)) return@forEach
                for (sub in listOf("cache", "code_cache")) {
                    val p = "/data/data/$pkg/$sub"
                    // 文件夹白名单也对 data 目录生效
                    if (whitePaths.any { p.startsWith(it) }) continue
                    val sz = ShellUtils.exec(
                        "du -sk $p 2>/dev/null | awk '{print \$1}'", root = true
                    ).out.trim().toLongOrNull() ?: 0L
                    if (sz > 0) {
                        ShellUtils.exec("rm -rf $p 2>/dev/null", root = true)
                        freedBytes += sz * 1024
                        fileCount++
                    }
                }
            }
        }

        cb.onProgress(100, "完成")
        val skipped = whiteApps.size + whitePaths.size
        cb.onDone("共清理 $fileCount 项垃圾，释放空间 ${SystemInfo.formatSize(freedBytes)}" +
                if (skipped > 0) "（已跳过 $skipped 个白名单项）" else "")
    }

    // ============================================================
    // 功能四：应用管理（列出应用，供卸载/禁用/打开）
    // ============================================================
    data class AppItem(
        val label: String,
        val pkg: String,
        val sizeBytes: Long,
        val isSystem: Boolean
    )

    fun listApps(includeSystem: Boolean = false): List<AppItem> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .filter { includeSystem || (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .map {
                val apkSize = try { File(it.sourceDir).length() } catch (e: Exception) { 0L }
                AppItem(
                    labelOf(pm, it), it.packageName, apkSize,
                    (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                )
            }
            .sortedByDescending { it.sizeBytes }
    }

    /** 卸载应用：root 直接 pm uninstall，普通跳系统卸载页。 */
    fun uninstall(pkg: String): Boolean {
        return if (isRoot) {
            ShellUtils.exec("pm uninstall --user 0 $pkg", root = true, timeoutMs = 15000).ok
        } else false   // 普通模式由 UI 跳系统卸载 Intent
    }

    /** 停止应用运行。 */
    fun forceStop(pkg: String): Boolean {
        return if (isRoot) {
            ShellUtils.exec("am force-stop $pkg", root = true, timeoutMs = 8000).ok
        } else {
            try {
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                am.killBackgroundProcesses(pkg); true
            } catch (e: Exception) { false }
        }
    }

    /** 清除应用数据/缓存。 */
    fun clearAppCache(pkg: String): Boolean {
        return if (isRoot) {
            ShellUtils.exec("pm clear $pkg", root = true, timeoutMs = 10000).ok
        } else false
    }

    // ============================================================
    // 工具方法
    // ============================================================
    private fun labelOf(pm: PackageManager, app: ApplicationInfo): String =
        try { pm.getApplicationLabel(app).toString() } catch (e: Exception) { app.packageName }

    private fun dirSizeAndCount(dir: File): Pair<Long, Int> {
        var size = 0L; var cnt = 0
        dir.walkTopDown().forEach {
            if (it.isFile) { size += it.length(); cnt++ }
        }
        return size to cnt
    }

    private fun deleteRecursive(dir: File, whitePaths: Set<String>) {
        if (whitePaths.any { dir.absolutePath.startsWith(it) }) return
        dir.listFiles()?.forEach {
            if (it.isDirectory) deleteRecursive(it, whitePaths) else it.delete()
        }
        dir.delete()
    }
}
