package com.clean.master.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.clean.master.R
import com.clean.master.core.Cleaner
import com.clean.master.core.Prefs
import com.clean.master.core.ShellUtils
import com.clean.master.core.SystemInfo
import com.clean.master.databinding.ActivityMainBinding
import com.clean.master.databinding.DialogProgressBinding
import com.google.android.material.progressindicator.LinearProgressIndicator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val cleaner by lazy { Cleaner(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        bindFuncCard(b.cardApp.root, R.drawable.ic_app, "应用管理")
        bindFuncCard(b.cardKill.root, R.drawable.ic_kill, "杀死后台")
        bindFuncCard(b.cardEat.root, R.drawable.ic_eat, "吃掉内存")
        bindFuncCard(b.cardJunk.root, R.drawable.ic_junk, "清理垃圾")

        // 顶部模式切换
        updateModeChip()
        b.btnMode.setOnClickListener { toggleMode() }

        // 白名单
        b.btnWhiteList.setOnClickListener {
            startActivity(Intent(this, WhiteListActivity::class.java))
        }

        // 四大功能
        b.cardApp.root.setOnClickListener {
            startActivity(Intent(this, AppManagerActivity::class.java))
        }
        b.cardKill.root.setOnClickListener { runKill() }
        b.cardEat.root.setOnClickListener { runEat() }
        b.cardJunk.root.setOnClickListener { runJunk() }
    }

    override fun onResume() {
        super.onResume()
        refreshUsage()
        updateModeChip()
    }

    // ---------------- 顶部两条进度条 ----------------
    private fun refreshUsage() {
        val s = SystemInfo.storage()
        b.tvStorage.text = "已使用 ${SystemInfo.formatSize(s.usedBytes)}"
        b.tvStorageTotal.text =
            "内部存储空间 总计 ${SystemInfo.formatSize(s.totalBytes)}（剩余 ${SystemInfo.formatSize(s.freeBytes)}）"
        animateBar(b.pbStorage, s.percent)

        val r = SystemInfo.ram(this)
        b.tvRam.text = "运行 ${SystemInfo.formatSize(r.usedBytes)}"
        b.tvRamTotal.text =
            "运行内存 总计 ${SystemInfo.formatSize(r.totalBytes)}（可用 ${SystemInfo.formatSize(r.freeBytes)}）"
        animateBar(b.pbRam, r.percent)
    }

    private fun animateBar(bar: LinearProgressIndicator, percent: Int) {
        bar.max = 100
        bar.setProgressCompat(percent.coerceIn(0, 100), true)
    }

    // ---------------- 模式切换 ----------------
    private fun updateModeChip() {
        if (Prefs.isRoot(this)) {
            b.btnMode.text = getString(R.string.mode_root)
        } else {
            b.btnMode.text = getString(R.string.mode_normal)
        }
    }

    private fun toggleMode() {
        if (Prefs.isRoot(this)) {
            Prefs.setMode(this, Prefs.MODE_NORMAL)
            updateModeChip()
            toast("已切换到普通模式")
            return
        }
        // 切到 root 前先检测可用性
        b.btnMode.text = "检测 root…"
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { ShellUtils.checkRoot() }
            if (ok) {
                Prefs.setMode(this@MainActivity, Prefs.MODE_ROOT)
                updateModeChip()
                toast("已切换到 Root 模式，可深层清理")
            } else {
                updateModeChip()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("无法启用 Root 模式")
                    .setMessage("未检测到 su 权限。请确认设备已通过 Magisk 获取 root，并在弹出的授权框中允许本应用。")
                    .setPositiveButton("知道了", null)
                    .show()
            }
        }
    }

    // ---------------- 功能执行 ----------------
    private fun runKill() = runTask("杀死后台") { cleaner.killBackground(it) }
    private fun runEat() = runTask("吃掉内存") { cleaner.eatMemory(it) }

    private fun runJunk() {
        AlertDialog.Builder(this)
            .setTitle("清理垃圾")
            .setMessage(
                if (Prefs.isRoot(this))
                    "当前为 Root 模式，将深层清理应用缓存、系统临时文件等。白名单目录会被跳过。"
                else
                    "当前为普通模式，将清理可访问的缓存与临时文件。白名单目录会被跳过。"
            )
            .setPositiveButton("开始清理") { _, _ ->
                runTask("清理垃圾") { cleaner.cleanJunk(it) }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    /** 通用：弹出环形进度对话框并在后台执行任务。 */
    private fun runTask(title: String, block: (Cleaner.Progress) -> Unit) {
        val db = DialogProgressBinding.inflate(layoutInflater)
        db.dpTitle.text = title
        val dialog = AlertDialog.Builder(this)
            .setView(db.root)
            .setCancelable(false)
            .create()
        dialog.show()

        val cb = object : Cleaner.Progress {
            override fun onProgress(percent: Int, label: String) {
                runOnUiThread {
                    db.dpCircle.setProgress(percent)
                    db.dpLabel.text = label
                }
            }

            override fun onDone(summary: String) {
                runOnUiThread {
                    db.dpCircle.setProgress(100)
                    db.dpLabel.text = summary
                    db.dpDone.visibility = View.VISIBLE
                    db.dpDone.setOnClickListener {
                        dialog.dismiss()
                        refreshUsage()
                    }
                }
            }
        }

        lifecycleScope.launch(Dispatchers.IO) { block(cb) }
    }

    // ---------------- 工具 ----------------
    private fun bindFuncCard(root: View, iconRes: Int, text: String) {
        root.findViewById<ImageView>(R.id.funcIcon).setImageResource(iconRes)
        root.findViewById<TextView>(R.id.funcText).text = text
    }

    private fun toast(msg: String) =
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()
}
