package com.clean.master.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.clean.master.core.Cleaner
import com.clean.master.core.Prefs
import com.clean.master.core.SystemInfo
import com.clean.master.databinding.ActivityAppManagerBinding
import com.clean.master.databinding.ItemAppBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppManagerActivity : AppCompatActivity() {

    private lateinit var b: ActivityAppManagerBinding
    private val cleaner by lazy { Cleaner(this) }
    private val adapter = AppAdapter { showActions(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAppManagerBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.rvApps.layoutManager = LinearLayoutManager(this)
        b.rvApps.adapter = adapter
        load()
    }

    private fun load() {
        lifecycleScope.launch {
            val apps = withContext(Dispatchers.IO) { cleaner.listApps(includeSystem = false) }
            adapter.submit(apps)
        }
    }

    private fun showActions(app: Cleaner.AppItem) {
        val root = Prefs.isRoot(this)
        val actions = listOf("打开应用", "停止运行", "清除数据", "卸载")
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(actions.toTypedArray()) { _, which ->
                when (which) {
                    0 -> openApp(app.pkg)
                    1 -> doForceStop(app.pkg)
                    2 -> doClear(app, root)
                    3 -> doUninstall(app, root)
                }
            }
            .show()
    }

    private fun openApp(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else toast("无法打开该应用")
    }

    private fun doForceStop(pkg: String) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { cleaner.forceStop(pkg) }
            toast(if (ok) "已停止运行" else "停止失败（普通模式仅能结束后台进程）")
        }
    }

    private fun doClear(app: Cleaner.AppItem, root: Boolean) {
        if (root) {
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) { cleaner.clearAppCache(app.pkg) }
                toast(if (ok) "已清除 ${app.label} 的数据" else "清除失败")
            }
        } else {
            // 普通模式跳系统应用详情页
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:${app.pkg}"))
            )
        }
    }

    private fun doUninstall(app: Cleaner.AppItem, root: Boolean) {
        if (root) {
            AlertDialog.Builder(this)
                .setTitle("卸载 ${app.label}")
                .setMessage("Root 模式将直接卸载该应用，确定？")
                .setPositiveButton("卸载") { _, _ ->
                    lifecycleScope.launch {
                        val ok = withContext(Dispatchers.IO) { cleaner.uninstall(app.pkg) }
                        toast(if (ok) "已卸载" else "卸载失败")
                        if (ok) load()
                    }
                }
                .setNegativeButton("取消", null)
                .show()
        } else {
            startActivity(
                Intent(Intent.ACTION_DELETE).setData(Uri.parse("package:${app.pkg}"))
            )
        }
    }

    private fun toast(msg: String) =
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()

    // ---------------- Adapter ----------------
    class AppAdapter(val onClick: (Cleaner.AppItem) -> Unit) :
        RecyclerView.Adapter<AppAdapter.VH>() {

        private val data = mutableListOf<Cleaner.AppItem>()

        fun submit(list: List<Cleaner.AppItem>) {
            data.clear(); data.addAll(list); notifyDataSetChanged()
        }

        class VH(val v: ItemAppBinding) : RecyclerView.ViewHolder(v.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return VH(v)
        }

        override fun getItemCount() = data.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val app = data[position]
            val pm = holder.itemView.context.packageManager
            holder.v.appName.text = app.label
            holder.v.appPkg.text = app.pkg
            holder.v.appSize.text = SystemInfo.formatSize(app.sizeBytes)
            try {
                holder.v.appIcon.setImageDrawable(pm.getApplicationIcon(app.pkg))
            } catch (e: Exception) {
                holder.v.appIcon.setImageResource(com.clean.master.R.drawable.ic_app)
            }
            holder.itemView.setOnClickListener { onClick(app) }
        }
    }
}
