package com.clean.master.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator

/** 圆环进度 View，功能执行时显示中央百分比 + 渐变进度圆环。 */
class CircleProgressView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#33FFFFFF")
        strokeCap = Paint.Cap.ROUND
    }
    private val fgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private var progress = 0f          // 0..100
    private var displayProgress = 0f
    private val oval = RectF()
    private var anim: ValueAnimator? = null

    var startColor = Color.parseColor("#4FC3F7")
    var endColor = Color.parseColor("#2962FF")

    fun setProgress(p: Int, animate: Boolean = true) {
        val target = p.coerceIn(0, 100).toFloat()
        progress = target
        if (animate) {
            anim?.cancel()
            anim = ValueAnimator.ofFloat(displayProgress, target).apply {
                duration = 350
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    displayProgress = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            displayProgress = target
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val stroke = w * 0.07f
        bgPaint.strokeWidth = stroke
        fgPaint.strokeWidth = stroke
        textPaint.textSize = w * 0.22f
        val pad = stroke / 2 + 4
        oval.set(pad, pad, w - pad, h - pad)
        fgPaint.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            startColor, endColor, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawArc(oval, 0f, 360f, false, bgPaint)
        val sweep = 360f * displayProgress / 100f
        canvas.drawArc(oval, -90f, sweep, false, fgPaint)
        val cy = height / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText("${displayProgress.toInt()}%", width / 2f, cy, textPaint)
    }
}
