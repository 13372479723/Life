package com.clean.master.core

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.StatFs

/** 读取存储 / 运行内存用量，供主页两条进度条使用。 */
object SystemInfo {

    data class Usage(val usedBytes: Long, val totalBytes: Long) {
        val freeBytes get() = totalBytes - usedBytes
        val percent get() = if (totalBytes == 0L) 0 else (usedBytes * 100 / totalBytes).toInt()
    }

    /** 内部存储空间用量。 */
    fun storage(): Usage {
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.blockCountLong * stat.blockSizeLong
        val free = stat.availableBlocksLong * stat.blockSizeLong
        return Usage(total - free, total)
    }

    /** 运行内存用量。 */
    fun ram(ctx: Context): Usage {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem
        val avail = mi.availMem
        return Usage(total - avail, total)
    }

    fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var v = bytes.toDouble()
        var i = 0
        while (v >= 1024 && i < units.size - 1) {
            v /= 1024; i++
        }
        return String.format("%.2f%s", v, units[i])
    }
}
