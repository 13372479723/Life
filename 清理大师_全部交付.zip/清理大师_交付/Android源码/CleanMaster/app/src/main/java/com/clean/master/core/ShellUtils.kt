package com.clean.master.core

import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader

/**
 * Shell 执行工具。
 * 普通模式: 用 sh 执行（权限受系统限制）。
 * root 模式: 用 su 执行（可深层清理 /data/data/*/cache、am force-stop 等）。
 */
object ShellUtils {

    data class Result(val code: Int, val out: String, val err: String) {
        val ok get() = code == 0
    }

    @Volatile
    var rootAvailable: Boolean? = null

    /** 检测设备是否具备 root。结果缓存。 */
    fun checkRoot(): Boolean {
        rootAvailable?.let { return it }
        val paths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/su/bin/su", "/system/sbin/su", "/vendor/bin/su"
        )
        var found = paths.any { java.io.File(it).exists() }
        if (!found) {
            // 兜底: 直接尝试执行 su -c id
            found = try {
                val r = exec(listOf("id"), root = true, timeoutMs = 4000)
                r.ok && r.out.contains("uid=0")
            } catch (e: Exception) {
                false
            }
        }
        rootAvailable = found
        return found
    }

    /**
     * 执行一组命令。
     * @param cmds 命令列表（会逐行写入）
     * @param root 是否用 su
     */
    fun exec(cmds: List<String>, root: Boolean, timeoutMs: Long = 30000): Result {
        val shell = if (root) "su" else "sh"
        return try {
            val process = Runtime.getRuntime().exec(shell)
            val os = DataOutputStream(process.outputStream)
            for (c in cmds) {
                os.writeBytes(c + "\n")
            }
            os.writeBytes("exit\n")
            os.flush()

            val out = StringBuilder()
            val err = StringBuilder()
            val tOut = Thread {
                BufferedReader(InputStreamReader(process.inputStream)).forEachLine {
                    out.append(it).append('\n')
                }
            }
            val tErr = Thread {
                BufferedReader(InputStreamReader(process.errorStream)).forEachLine {
                    err.append(it).append('\n')
                }
            }
            tOut.start(); tErr.start()

            val finished = process.waitFor(timeoutMs / 1000, java.util.concurrent.TimeUnit.SECONDS)
            if (!finished) {
                process.destroy()
                return Result(-1, out.toString(), "命令超时")
            }
            tOut.join(2000); tErr.join(2000)
            Result(process.exitValue(), out.toString().trim(), err.toString().trim())
        } catch (e: Exception) {
            Result(-1, "", e.message ?: "执行失败")
        }
    }

    fun exec(cmd: String, root: Boolean, timeoutMs: Long = 30000): Result =
        exec(listOf(cmd), root, timeoutMs)
}
