#!/system/bin/sh
# =====================================================================
#  清理大师 clean_master.sh
#  四大功能：应用管理 / 杀死后台 / 吃掉内存 / 清理垃圾(带白名单)
#  特性：彩色 ASCII 进度条 UI、普通/Root 双模式、清理白名单(应用+文件夹)
#  适配：Android (Magisk/root) 的 sh / bash / Termux
# =====================================================================

# ---------------------------------------------------------------------
# 配置与白名单文件
# ---------------------------------------------------------------------
CFG_DIR="${HOME:-/sdcard}/.clean_master"
WL_APP="$CFG_DIR/whitelist_app.txt"     # 清理垃圾·应用白名单(每行一个包名)
WL_PATH="$CFG_DIR/whitelist_path.txt"   # 清理垃圾·文件夹白名单(每行一个目录)
mkdir -p "$CFG_DIR" 2>/dev/null

# 文件夹白名单默认值（首次创建）
if [ ! -f "$WL_PATH" ]; then
  cat > "$WL_PATH" <<EOF
/storage/emulated/0/DCIM
/storage/emulated/0/Pictures
/storage/emulated/0/Download
/storage/emulated/0/Documents
EOF
fi
[ -f "$WL_APP" ] || : > "$WL_APP"

# ---------------------------------------------------------------------
# 颜色与 UI
# ---------------------------------------------------------------------
ESC=$(printf '\033')
C_RESET="${ESC}[0m";  C_BOLD="${ESC}[1m"
C_CYAN="${ESC}[36m";  C_GREEN="${ESC}[32m"; C_YELLOW="${ESC}[33m"
C_RED="${ESC}[31m";   C_BLUE="${ESC}[34m";  C_MAGENTA="${ESC}[35m"
C_GRAY="${ESC}[90m"

# 运行模式：normal / root
MODE="normal"

# Root 检测
has_root() {
  for p in /system/bin/su /system/xbin/su /sbin/su /su/bin/su /vendor/bin/su; do
    [ -x "$p" ] && return 0
  done
  command -v su >/dev/null 2>&1 && return 0
  return 1
}

# 以当前模式执行命令；root 模式用 su -c
RUN() {
  if [ "$MODE" = "root" ]; then
    su -c "$*" 2>/dev/null
  else
    sh -c "$*" 2>/dev/null
  fi
}

# 彩色进度条： draw_bar <percent> <label>
draw_bar() {
  pct=$1; label=$2
  [ "$pct" -gt 100 ] && pct=100
  [ "$pct" -lt 0 ] && pct=0
  width=30
  filled=$(( pct * width / 100 ))
  empty=$(( width - filled ))
  # 颜色随进度变化
  if   [ "$pct" -lt 40 ]; then col=$C_RED
  elif [ "$pct" -lt 75 ]; then col=$C_YELLOW
  else col=$C_GREEN; fi
  bar=""
  i=0; while [ $i -lt $filled ]; do bar="${bar}█"; i=$((i+1)); done
  j=0; while [ $j -lt $empty  ]; do bar="${bar}░"; j=$((j+1)); done
  printf "\r  %s[%s%s%s] %s%3d%%%s  %-28.28s" \
    "$C_BOLD" "$col" "$bar" "$C_RESET$C_BOLD" "$col" "$pct" "$C_RESET" "$label"
}

bar_done() { printf "\n"; }

line() { printf "%s%s%s\n" "$C_GRAY" "────────────────────────────────────────────────" "$C_RESET"; }

human() {  # 字节转可读
  b=$1
  awk -v b="$b" 'BEGIN{
    s="B KB MB GB TB"; n=split(s,u," "); v=b; i=1;
    while(v>=1024 && i<n){v/=1024;i++}
    printf("%.2f%s", v, u[i]);
  }'
}

# ---------------------------------------------------------------------
# 顶部仪表盘：存储 + 内存 两条进度条（对应 APP 顶部那两条）
# ---------------------------------------------------------------------
dashboard() {
  clear 2>/dev/null
  printf "%s%s   🧹  清 理 大 师  CLEAN MASTER%s   [模式: %s]\n" \
    "$C_BOLD" "$C_CYAN" "$C_RESET" \
    "$( [ "$MODE" = root ] && printf "%sROOT%s" "$C_GREEN" "$C_RESET" || printf "%s普通%s" "$C_YELLOW" "$C_RESET" )"
  line

  # 存储
  read_st=$(df /data 2>/dev/null | awk 'NR==2{print $2" "$3}')
  s_total_k=$(echo "$read_st" | awk '{print $1}')
  s_used_k=$(echo "$read_st" | awk '{print $2}')
  if [ -n "$s_total_k" ] && [ "$s_total_k" -gt 0 ] 2>/dev/null; then
    s_pct=$(( s_used_k * 100 / s_total_k ))
    printf "  %s存储%s 已用 %s / 总 %s\n" "$C_BOLD" "$C_RESET" \
      "$(human $((s_used_k*1024)))" "$(human $((s_total_k*1024)))"
    draw_bar "$s_pct" "internal storage"; bar_done
  fi

  # 内存
  if [ -r /proc/meminfo ]; then
    m_total_k=$(awk '/MemTotal/{print $2}' /proc/meminfo)
    m_avail_k=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
    [ -z "$m_avail_k" ] && m_avail_k=$(awk '/MemFree/{print $2}' /proc/meminfo)
    m_used_k=$(( m_total_k - m_avail_k ))
    m_pct=$(( m_used_k * 100 / m_total_k ))
    printf "  %s内存%s 已用 %s / 总 %s\n" "$C_BOLD" "$C_RESET" \
      "$(human $((m_used_k*1024)))" "$(human $((m_total_k*1024)))"
    draw_bar "$m_pct" "RAM"; bar_done
  fi
  line
}

# ---------------------------------------------------------------------
# 功能一：应用管理
# ---------------------------------------------------------------------
app_manager() {
  dashboard
  printf "  %s应用管理%s（仅列出第三方应用）\n" "$C_BOLD$C_BLUE" "$C_RESET"
  line
  pkgs=$(RUN "pm list packages -3" | sed 's/package://' | sort)
  [ -z "$pkgs" ] && pkgs=$(pm list packages -3 2>/dev/null | sed 's/package://' | sort)
  n=0
  echo "$pkgs" | while IFS= read -r p; do
    [ -z "$p" ] && continue
    n=$((n+1))
    printf "  %s%3d.%s %s\n" "$C_GRAY" "$n" "$C_RESET" "$p"
  done
  echo
  printf "  输入要操作的包名(回车跳过): "
  read pkg
  [ -z "$pkg" ] && return
  printf "  %s1%s)停止运行  %s2%s)清除数据  %s3%s)卸载  其它)取消  : " \
    "$C_GREEN" "$C_RESET" "$C_YELLOW" "$C_RESET" "$C_RED" "$C_RESET"
  read act
  case "$act" in
    1) RUN "am force-stop $pkg"; printf "  %s已停止 %s%s\n" "$C_GREEN" "$pkg" "$C_RESET" ;;
    2) RUN "pm clear $pkg";      printf "  %s已清除数据 %s%s\n" "$C_GREEN" "$pkg" "$C_RESET" ;;
    3) RUN "pm uninstall --user 0 $pkg"; printf "  %s已卸载 %s%s\n" "$C_GREEN" "$pkg" "$C_RESET" ;;
    *) printf "  已取消\n" ;;
  esac
  printf "\n  回车返回..."; read _
}

# ---------------------------------------------------------------------
# 功能二：杀死后台
# ---------------------------------------------------------------------
kill_background() {
  dashboard
  printf "  %s杀死后台%s\n" "$C_BOLD$C_BLUE" "$C_RESET"; line
  list=$(RUN "pm list packages -3" | sed 's/package://')
  [ -z "$list" ] && list=$(pm list packages -3 2>/dev/null | sed 's/package://')
  total=$(echo "$list" | grep -c .)
  [ "$total" -eq 0 ] && total=1
  i=0; killed=0
  echo "$list" | while IFS= read -r p; do
    [ -z "$p" ] && continue
    i=$((i+1))
    if [ "$MODE" = "root" ]; then
      su -c "am force-stop $p" 2>/dev/null && killed=$((killed+1))
    else
      am kill "$p" 2>/dev/null
    fi
    pct=$(( i * 100 / total ))
    draw_bar "$pct" "结束: $p"
  done
  bar_done
  printf "  %s✔ 后台清理完成%s\n" "$C_GREEN" "$C_RESET"
  printf "\n  回车返回..."; read _
}

# ---------------------------------------------------------------------
# 功能三：吃掉内存（释放运行内存）
# ---------------------------------------------------------------------
eat_memory() {
  dashboard
  printf "  %s吃掉内存%s\n" "$C_BOLD$C_BLUE" "$C_RESET"; line
  before=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
  draw_bar 15 "同步文件系统 sync"; RUN "sync"; sleep 0
  draw_bar 45 "释放页缓存 drop_caches"
  if [ "$MODE" = "root" ]; then
    su -c "echo 3 > /proc/sys/vm/drop_caches" 2>/dev/null
    draw_bar 75 "回收应用内存 am kill-all"
    su -c "am kill-all" 2>/dev/null
  else
    # 普通模式：尽力杀后台
    for p in $(pm list packages -3 2>/dev/null | sed 's/package://'); do
      am kill "$p" 2>/dev/null
    done
    draw_bar 75 "请求系统回收内存"
  fi
  draw_bar 100 "完成"; bar_done
  after=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
  freed=$(( (after - before) * 1024 ))
  [ "$freed" -lt 0 ] && freed=0
  printf "  %s✔ 本次释放运行内存约 %s%s\n" "$C_GREEN" "$(human $freed)" "$C_RESET"
  printf "\n  回车返回..."; read _
}

# ---------------------------------------------------------------------
# 功能四：清理垃圾（带白名单：应用 + 文件夹）
# ---------------------------------------------------------------------
in_path_whitelist() {  # $1 路径
  while IFS= read -r w; do
    [ -z "$w" ] && continue
    case "$1" in "$w"*) return 0;; esac
  done < "$WL_PATH"
  return 1
}
in_app_whitelist() {   # $1 包名
  grep -qxF "$1" "$WL_APP" 2>/dev/null
}

clean_junk() {
  dashboard
  printf "  %s清理垃圾%s  (应用白名单 %s 条 / 文件夹白名单 %s 条)\n" \
    "$C_BOLD$C_BLUE" "$C_RESET" \
    "$(grep -c . "$WL_APP" 2>/dev/null)" "$(grep -c . "$WL_PATH" 2>/dev/null)"
  line
  freed=0; cnt=0
  sd="/storage/emulated/0"

  # 阶段一：外置存储可见垃圾目录
  dir_targets="$sd/.thumbnails $sd/DCIM/.thumbnails $sd/Android/.Trash $sd/LOST.DIR $sd/.temp $sd/temp $sd/.cache"
  set -- $dir_targets
  dtot=$#
  # root 阶段二要遍历的应用数
  if [ "$MODE" = "root" ]; then
    apps=$(su -c "pm list packages" 2>/dev/null | sed 's/package://')
    atot=$(echo "$apps" | grep -c .)
  else
    apps=""; atot=0
  fi
  total=$(( dtot + atot )); [ "$total" -eq 0 ] && total=1
  step=0

  for t in $dir_targets; do
    step=$((step+1)); pct=$(( step * 100 / total ))
    draw_bar "$pct" "目录: $(basename "$t")"
    if in_path_whitelist "$t"; then continue; fi
    if [ -d "$t" ]; then
      sz=$(RUN "du -sk '$t'" | awk '{print $1}')
      [ -z "$sz" ] && sz=0
      RUN "rm -rf '$t'"
      freed=$(( freed + sz * 1024 )); cnt=$((cnt+1))
    fi
  done

  # 阶段二：root 逐应用清缓存，跳过应用白名单
  # 用临时文件喂 while，避免管道子 shell 导致统计变量丢失
  if [ "$MODE" = "root" ]; then
    tmp_apps="$CFG_DIR/.apps.$$"
    echo "$apps" > "$tmp_apps"
    while IFS= read -r p; do
      [ -z "$p" ] && continue
      step=$((step+1)); pct=$(( step * 100 / total ))
      draw_bar "$pct" "缓存: $p"
      in_app_whitelist "$p" && continue
      for sub in cache code_cache; do
        d="/data/data/$p/$sub"
        in_path_whitelist "$d" && continue
        sz=$(su -c "du -sk '$d' 2>/dev/null" | awk '{print $1}')
        [ -z "$sz" ] && sz=0
        if [ "$sz" -gt 0 ]; then
          su -c "rm -rf '$d'" 2>/dev/null
          freed=$(( freed + sz * 1024 )); cnt=$((cnt+1))
        fi
      done
    done < "$tmp_apps"
    rm -f "$tmp_apps"
  fi

  draw_bar 100 "完成"; bar_done
  printf "  %s✔ 清理完成，共 %s 项，释放约 %s%s\n" "$C_GREEN" "$cnt" "$(human $freed)" "$C_RESET"
  printf "\n  回车返回..."; read _
}

# ---------------------------------------------------------------------
# 从已安装应用列表按编号勾选加入「清理·应用」白名单
# ---------------------------------------------------------------------
pick_app_to_whitelist() {
  dashboard
  printf "  %s选择应用加入清理白名单%s（已在名单的标 %s✔%s）\n" \
    "$C_BOLD$C_MAGENTA" "$C_RESET" "$C_GREEN" "$C_RESET"; line

  # 拉取第三方应用列表（root 下可看全部，这里只列第三方更实用）
  tmp_list="$CFG_DIR/.applist.$$"
  RUN "pm list packages -3" | sed 's/package://' | sort > "$tmp_list"
  [ -s "$tmp_list" ] || pm list packages -3 2>/dev/null | sed 's/package://' | sort > "$tmp_list"

  if [ ! -s "$tmp_list" ]; then
    printf "  %s未获取到应用列表%s\n" "$C_RED" "$C_RESET"; rm -f "$tmp_list"
    printf "\n  回车返回..."; read _; return
  fi

  # 带编号 + 勾选状态展示
  idx=0
  while IFS= read -r p; do
    [ -z "$p" ] && continue
    idx=$((idx+1))
    if grep -qxF "$p" "$WL_APP" 2>/dev/null; then mark="$C_GREEN✔$C_RESET"; else mark=" "; fi
    printf "  %s%3d%s [%s] %s\n" "$C_GRAY" "$idx" "$C_RESET" "$mark" "$p"
  done < "$tmp_list"
  line
  printf "  输入编号切换勾选(可空格分隔多个，如 1 3 5)，回车返回: "
  read nums
  [ -z "$nums" ] && { rm -f "$tmp_list"; return; }

  for n in $nums; do
    # 取第 n 行包名
    pkg=$(sed -n "${n}p" "$tmp_list")
    [ -z "$pkg" ] && continue
    if grep -qxF "$pkg" "$WL_APP" 2>/dev/null; then
      # 已在名单 -> 取消
      grep -vxF "$pkg" "$WL_APP" > "$WL_APP.tmp" && mv "$WL_APP.tmp" "$WL_APP"
      printf "  %s- 移出白名单: %s%s\n" "$C_YELLOW" "$pkg" "$C_RESET"
    else
      echo "$pkg" >> "$WL_APP"
      printf "  %s+ 加入白名单: %s%s\n" "$C_GREEN" "$pkg" "$C_RESET"
    fi
  done
  rm -f "$tmp_list"
  printf "\n  回车返回..."; read _
}

# ---------------------------------------------------------------------
# 白名单管理（手动添加 应用 / 文件夹）
# ---------------------------------------------------------------------
whitelist_menu() {
  while :; do
    dashboard
    printf "  %s清理白名单管理%s\n" "$C_BOLD$C_MAGENTA" "$C_RESET"; line
    printf "  %s应用白名单 (%s 条):%s\n" "$C_BOLD" "$(grep -c . "$WL_APP" 2>/dev/null)" "$C_RESET"
    nl -ba "$WL_APP" 2>/dev/null | sed 's/^/    /'
    printf "  %s文件夹白名单 (%s 条):%s\n" "$C_BOLD" "$(grep -c . "$WL_PATH" 2>/dev/null)" "$C_RESET"
    nl -ba "$WL_PATH" 2>/dev/null | sed 's/^/    /'
    line
    printf "  %s1%s)从列表勾选应用  %s2%s)手输包名加应用  %s3%s)删应用\n" \
      "$C_GREEN" "$C_RESET" "$C_GREEN" "$C_RESET" "$C_RED" "$C_RESET"
    printf "  %s4%s)加文件夹  %s5%s)删文件夹  %s0%s)返回 : " \
      "$C_GREEN" "$C_RESET" "$C_RED" "$C_RESET" "$C_GRAY" "$C_RESET"
    read c
    case "$c" in
      1) pick_app_to_whitelist ;;
      2) printf "  输入应用包名: "; read v
         [ -n "$v" ] && ! grep -qxF "$v" "$WL_APP" && echo "$v" >> "$WL_APP" ;;
      3) printf "  输入要删除的应用包名: "; read v
         [ -n "$v" ] && grep -vxF "$v" "$WL_APP" > "$WL_APP.tmp" && mv "$WL_APP.tmp" "$WL_APP" ;;
      4) printf "  输入文件夹绝对路径(/开头): "; read v
         case "$v" in /*) grep -qxF "$v" "$WL_PATH" || echo "$v" >> "$WL_PATH";;
            *) printf "  %s路径需以 / 开头%s\n" "$C_RED" "$C_RESET"; sleep 1;; esac ;;
      5) printf "  输入要删除的文件夹路径: "; read v
         [ -n "$v" ] && grep -vxF "$v" "$WL_PATH" > "$WL_PATH.tmp" && mv "$WL_PATH.tmp" "$WL_PATH" ;;
      0) return ;;
    esac
  done
}

# ---------------------------------------------------------------------
# 模式切换
# ---------------------------------------------------------------------
toggle_mode() {
  if [ "$MODE" = "root" ]; then
    MODE="normal"
  else
    if has_root && su -c "id" 2>/dev/null | grep -q "uid=0"; then
      MODE="root"
    else
      printf "  %s未获取到 root 权限，请在 Magisk 中授权后重试%s\n" "$C_RED" "$C_RESET"
      sleep 2
    fi
  fi
}

# ---------------------------------------------------------------------
# 主菜单
# ---------------------------------------------------------------------
main_menu() {
  while :; do
    dashboard
    printf "  %s┏━━━━━━━━━ 功 能 ━━━━━━━━━┓%s\n" "$C_CYAN" "$C_RESET"
    printf "    %s1%s  应用管理\n" "$C_GREEN" "$C_RESET"
    printf "    %s2%s  杀死后台\n" "$C_GREEN" "$C_RESET"
    printf "    %s3%s  吃掉内存\n" "$C_GREEN" "$C_RESET"
    printf "    %s4%s  清理垃圾（带白名单）\n" "$C_GREEN" "$C_RESET"
    printf "    %s5%s  白名单管理（加/删 应用·文件夹）\n" "$C_MAGENTA" "$C_RESET"
    printf "    %sm%s  切换模式（当前: %s）\n" "$C_YELLOW" "$C_RESET" \
      "$( [ "$MODE" = root ] && echo ROOT || echo 普通 )"
    printf "    %s0%s  退出\n" "$C_GRAY" "$C_RESET"
    printf "  %s┗━━━━━━━━━━━━━━━━━━━━━━━━━┛%s\n" "$C_CYAN" "$C_RESET"
    printf "  请选择: "
    read ch
    case "$ch" in
      1) app_manager ;;
      2) kill_background ;;
      3) eat_memory ;;
      4) clean_junk ;;
      5) whitelist_menu ;;
      m|M) toggle_mode ;;
      0) clear 2>/dev/null; printf "再见 👋\n"; exit 0 ;;
    esac
  done
}

# 启动时若有 root 默认提示
has_root && printf "%s检测到 root，可在菜单按 m 切换到 ROOT 模式以深层清理%s\n" "$C_GREEN" "$C_RESET" && sleep 1
main_menu
