#!/system/bin/sh
# 二合一救砖模块 —— 模块介绍合成脚本(后台运行)
# 周期性地把"固定功能说明 + 两套救砖的实时状态"写回主 module.prop
# 不修改任何原始救砖脚本, 仅读取它们产生的状态文件/统计文件

MODDIR=${0%/*}
PROP="$MODDIR/module.prop"
AUTO_LOG="$MODDIR/auto/Number_of_brick_rescue.log"     # 自动救砖累计次数
MANUAL_LOG="$MODDIR/Log.txt"                            # 手动版开机/救砖日志
STATE="$MODDIR/.manual_state"                           # 音量监听状态标记(由本脚本判断)

# 固定的功能说明(文字不变, 只有状态数字变动)
FIX="功能一[音量键救砖]: 开机后三击音量+进入magisk核心模式并禁用所有模块,三击音量-禁用Xposed模块。功能二[自动救砖]: 卡开机自动清缓存/关SELinux/进安全模式/禁模块兜底。"

# 安全写入 description(用 grep -v + printf, 避免 sed 误解析特殊字符)
write_prop() {
    NEWDESC="$1"
    TMP="$PROP.tmp"
    grep -v '^description=' "$PROP" > "$TMP" 2>/dev/null
    printf 'description=%s\n' "$NEWDESC" >> "$TMP"
    mv -f "$TMP" "$PROP"
}

while true; do
    # 自动救砖次数
    if [ -f "$AUTO_LOG" ]; then
        AUTO_CNT=$(cat "$AUTO_LOG" 2>/dev/null | tr -dc '0-9')
    fi
    [ -z "$AUTO_CNT" ] && AUTO_CNT=0

    # 音量监听状态: 判断 keycheck 监听进程是否已结束
    # 手动版 service.sh 在开机校验阶段会跑 keycheck, 跑完即结束
    RUNNING=$(ps -ef 2>/dev/null | grep keycheck | grep -v grep | wc -l)
    if [ "$RUNNING" -ne 0 ]; then
        MSTATE="✓音量监听中"
    else
        MSTATE="✓音量监听结束"
    fi

    write_prop "[ $MSTATE | 自动救砖已生效 ] $FIX 累计自动救砖: ${AUTO_CNT}次。"

    sleep 60
done
