#!/system/bin/sh
# 二合一救砖模块 —— post-fs-data 阶段
# 功能一【神仙自动救砖】: 开机早期记录启动次数, 第2次清缓存/第3次关SELinux/第4次进安全模式
# 原始脚本未做任何改动, 仅由本入口调起

MODDIR=${0%/*}
export PATH="/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin:/system_ext/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:/data/user/0/Han.GJZS/files/usr/busybox:/dev/dcoF/.magisk/busybox"

# 调起自动救砖原始脚本(运行在 auto/ 子目录, 其内部 MODDIR 指向 auto/)
/system/bin/sh $MODDIR/auto/Automatic_brick_rescue.sh

exit 0
