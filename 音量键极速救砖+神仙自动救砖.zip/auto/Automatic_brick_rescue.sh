#!/system/bin/sh
#本脚本由搞机助手自动创建
#作者：by：Han | 情非得已c
#请不要试图篡改本脚本，否则一切后果自负，已安装版本：v2021013102(34)
#特别鸣谢Magisk提供服务支持：by topjohnwu


Disable_All_Modules() {
    ls "/data/adb/modules" | while read i; do
        [[ "$i" = "$MODID" ]] && continue
        touch "/data/adb/modules/$i/disable" &>/dev/null
    done
    reboot
}

Statistics() {
    if [[ ! -f $LOG ]]; then
        echo "1" >$LOG
    else
        Number_of_brick_rescue=`cat $LOG`
        p="$(expr $Number_of_brick_rescue + 1)"
        echo "$p" >$LOG
    fi
}


MODDIR=${0%/*}
MODID=${MODDIR##*/}
Module_XinXi=$MODDIR/module.prop
START_LOG=$MODDIR/Number_of_starts.log
LOG=$MODDIR/Number_of_brick_rescue.log


if [[ ! -f $START_LOG ]]; then
    echo 0 >"$START_LOG"
    Frequency2=1
else
    Frequency=`cat $START_LOG`
    Frequency2="$(expr $Frequency + 1)"
    echo "$Frequency2" >"$START_LOG"
fi
    if [[ $Frequency2 -eq 2 ]]; then
        rm -rf /data/system/package_cache/*
        Statistics
        reboot
    elif [[ $Frequency2 -eq 3 ]]; then
        setenforce 0
    elif [[ $Frequency2 -ge 4 ]]; then
        Statistics
        setprop persist.sys.safemode 1 && reboot
    fi
    exit 0
