#!/system/bin/sh
#本脚本由搞机助手自动创建
#作者：by：Han | 情非得已c
#请不要试图篡改本脚本，否则一切后果自负，已安装版本：v2021013102(34)
#特别鸣谢Magisk提供服务支持：by topjohnwu


Disable_All_Modules() {
    ls "/data/adb/modules" | while read i; do
        [[ "$i" = "$MODID" ]] && continue
        touch "/data/adb/modules/$i/disable" &>/dev/null
    done
    reboot
}

Statistics() {
    if [[ ! -f $LOG ]]; then
        echo "1" >$LOG
    else
        Number_of_brick_rescue=`cat $LOG`
        p="$(expr $Number_of_brick_rescue + 1)"
        echo "$p" >$LOG
    fi
}


MODDIR=${0%/*}
MODID=${MODDIR##*/}
Module_XinXi=$MODDIR/module.prop
START_LOG=$MODDIR/Number_of_starts.log
LOG=$MODDIR/Number_of_brick_rescue.log


    sleep 1.2m
    if [[ `getprop init.svc.bootanim` = "stopped" ]]; then
        rm -f "$START_LOG"
        if [[ -f $LOG ]]; then
            Number_of_brick_rescue=`cat $LOG`
            sed -i "/^description=/c description=用途：当刷入一些模块后导致无法正常开机，触发已设置的自动救砖操作方式：在重启第2次时清除系统包名缓存和关闭SELinux模块尝试第3次开机操作。如果再重启第4次时未开机，强制进入安全模式，同时删除启动记录次数文件，重新从1开始记录开机次数。正常启动卡在第二屏等待1.2分钟后无法开机，自动禁用所有模块尝试一次开机，已为您自动救砖：$Number_of_brick_rescue次。" "$Module_XinXi"
        fi
    else
        Statistics
        Disable_All_Modules
    fi

