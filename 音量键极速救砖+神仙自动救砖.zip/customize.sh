SKIPUNZIP=0

ui_print " "
ui_print "============================================"
ui_print "   二合一救砖模块"
ui_print "   功能一 = 音量键极速救砖 (小白杨)"
ui_print "   功能二 = 神仙自动救砖 (Han 情非得已c)"
ui_print "============================================"
ui_print " "
ui_print "- 功能一[音量键救砖]:"
ui_print "    开机后三击音量+ -> magisk核心模式并禁用所有模块"
ui_print "    三击音量-       -> 禁用 Xposed 模块"
ui_print "- 功能二[自动救砖]:"
ui_print "    卡开机自动 清缓存/关SELinux/进安全模式/禁模块 兜底"
ui_print " "

# 清空上一份的历史日志/统计(属于旧机主数据, 不应保留)
: > "$MODPATH/Log.txt" 2>/dev/null
rm -f "$MODPATH/.enable_apps" 2>/dev/null
rm -f "$MODPATH/auto/Number_of_starts.log" 2>/dev/null
rm -f "$MODPATH/auto/Number_of_brick_rescue.log" 2>/dev/null

# 给音量键检测二进制设可执行权限
set_perm "$MODPATH/keycheck" 0 0 0755

ui_print "- 安装完成, 重启后两套救砖将同时生效"
ui_print " "
