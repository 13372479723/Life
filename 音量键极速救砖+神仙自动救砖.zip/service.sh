#!/system/bin/sh
# 二合一救砖模块 —— service(late_start) 阶段
# 同时启动两套互不干扰的救砖程序 + 介绍合成脚本
# 两套原始救砖脚本均未改动, 仅由本入口调起

MODDIR=${0%/*}
export PATH="/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin:/system_ext/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:/data/user/0/Han.GJZS/files/usr/busybox:/dev/dcoF/.magisk/busybox"

# 功能二【神仙自动救砖】兜底脚本: sleep 1.2 分钟后判断是否开机成功, 否则禁用所有模块重启
# 运行在 auto/ 子目录(其内部 MODDIR 指向 auto/, 读写自己的 prop/log)
/system/bin/sh $MODDIR/auto/Automatic_brick_rescue2.sh &

# 功能一【音量键极速救砖】: 开机后监听音量键三连击, 手动触发救砖
# 必须在模块根目录运行(脚本内 dirname 依赖此路径来定位 /data/adb/modules)
/system/bin/sh $MODDIR/service_manual.sh &

# 介绍合成脚本: 把两套救砖的实时状态写回主 module.prop
/system/bin/sh $MODDIR/merge_desc.sh &

exit 0
