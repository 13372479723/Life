#/system/bin/sh

mkdir -p $MODPATH/log

test "$MODPATH" = "" && exit

oldsize=$(du -sm /data | tr -cd '[0-9]')

function limitlog() {
	local logfile=$1
	local maxsize=$((1024 * 1000))
	filesize=$(ls -l $logfile | awk '{ print $5 }')
	if test $filesize -gt $maxsize; then
		echo " " >$logfile
	fi
}

function whitelist() {
	local file=$MODPATH/notclear.conf
	cat $file | sed '/^#/d;/^[[:space:]]*$/d' | sed ':a;N;$!ba;s/\n/|/g'
}

function clear_emptydir() {
	find /data/media -type d -empty 2>/dev/null | while read emptydir; do
		if test "$(echo "$emptydir" | grep -w -E "$(whitelist)")" != ""; then
			echo "跳过清理$emptydir"
			continue
		else
			rm -rf "${emptydir}"
			echo "${emptydir}" >>$MODPATH/log/emptydir.log
		fi
	done
}

function clear_cachedir() {
	find /data/user* /data/data /data/media/*[0-9]*/Android -iname "*cache*" -type d 2>/dev/null | while read cachedir; do
		if test "$(echo "$cachedir" | grep -w -E "$(whitelist)")" != ""; then
			echo "跳过清理$cachedir"
			continue
		else
			rm -rf "${cachedir}"
			echo "${cachedir}" >>$MODPATH/log/cachedir.log
		fi
	done
}

function sort_uniq_log() {
	modlog=$(find $MODPATH -type f -iname "*.log" 2>/dev/null)
	for i in $modlog; do
		echo "$(sort $i | uniq)" >"$i"
	done
}

function clear_mod_log() {
	modlog=$(find $MODPATH -type f -iname "*.log" 2>/dev/null)
	for i in $modlog; do
		limitlog $i
	done
}

#运行主要脚本

clear_emptydir 2>/dev/null
clear_cachedir 2>/dev/null
sort_uniq_log 2>/dev/null
clear_mod_log 2>/dev/null

a=$(cat $MODPATH/log/emptydir.log | sed '/^[[:space:]]*$/d' | wc -l)
c=$(cat $MODPATH/log/cachedir.log | sed '/^[[:space:]]*$/d' | wc -l)

newsize=$(du -sm /data | tr -cd '[0-9]')
data_size=$(($oldsize - $newsize))

check_data_size=$(echo "$data_size" | grep -q '-' && echo "true")

test "$check_data_size" = "true" && {
	data_size=$(echo $data_size | tr -cd '[0-9]')
	echo "从模块开始运行到[ $(date '+%y年%m月%d日%T') ]，共清理空文件夹"$a"个，"$c"个应用缓存文件夹，本次运行储存空间增加了 "$data_size" MB。" >>$MODPATH/log/total.log
	# 注意：不再直接写 module.prop。模块描述统一由 merge_desc.sh 读取 log/total.log 后刷新，
	# 避免多个脚本并发写 module.prop 导致 name/author 丢失(显示成 id)或乱码。
	exit 0
}

echo "从模块开始运行到[ $(date '+%y年%m月%d日%T') ]，共清理空文件夹"$a"个，"$c"个应用缓存文件夹，本次运行储存空间释放了 "$data_size" MB。" >>$MODPATH/log/total.log
# 注意：不再直接写 module.prop。模块描述统一由 merge_desc.sh 读取 log/total.log 后刷新，
# 避免多个脚本并发写 module.prop 导致 name/author 丢失(显示成 id)或乱码。
