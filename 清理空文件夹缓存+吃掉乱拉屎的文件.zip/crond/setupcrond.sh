BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH
script_dir=${0%/*}
script_file=`find $script_dir -iname "*.sh" | sed "/${0##*/}/d"`

test -e $script_dir/root && {
crond -c $script_dir 
exit 0
}

test "$script_file" != "" && {
for i in $script_file ;do
#写入crontab时间
echo "0 6 * * * $i " >>$script_dir/root
echo "0 8 * * * $i " >>$script_dir/root
echo "0 10 * * * $i " >>$script_dir/root
echo "0 12 * * * $i " >>$script_dir/root
echo "0 14 * * * $i " >>$script_dir/root
echo "0 16 * * * $i " >>$script_dir/root
echo "0 18 * * * $i " >>$script_dir/root
echo "0 20 * * * $i " >>$script_dir/root
#设置脚本权限
chmod -R 0777 $script_dir
#添加Magisk自带的busybox
sed -i "2i export PATH=$BUSYBOXDIR:/system/bin:\$PATH" $i
sed -i "2i MODPATH=$MODPATH" $i
#执行crond任务。
done
crond -c $script_dir
for i in $script_file ;do  $i 2>/dev/null ;done
} || echo "不存在脚本文件！crond 启动失败！" > $MODPATH/crond/crond_error.log
# 注意：不再直接写 module.prop。crond 启动失败信息写入独立日志，避免污染模块描述。

