SKIPUNZIP=0
SKIPMOUNT=false

##############################################################################
# 功能一：清理空文件夹/应用缓存(作者 key) —— 原 customize.sh + busybox.sh 逻辑
##############################################################################
key_source(){
if test -e "$1" ;then
source "$1"
rm -rf "$1"
fi
}
key_source $MODPATH/key.sh
key_source $MODPATH/busybox.sh
test -d $MODPATH/busybox && {
set_perm $magiskbusybox 0 0 0755
chmod -R 0755 $MODPATH/busybox
}

##############################################################################
# 功能二：吃掉乱拉屎的文件/文件夹(作者 忆雨) —— 原 customize.sh 交互安装逻辑
# 说明：原模块2的运行脚本与规则文件已放入子目录 fuckshit/，故下方涉及的
#       files 目录路径同步指向 $MODPATH/fuckshit/files，规则文件来源同理。
##############################################################################
get_choose()
{
	local choose
	local branch
	while :; do
		choose="$(getevent -qlc 1 | awk '{ print $3 }')"
		case "$choose" in
		KEY_VOLUMEUP)  branch="0" ;;
		KEY_VOLUMEDOWN)  branch="1" ;;
		*)  continue ;;
		esac
		echo "$branch"
		break
	done
}

MyPrint()
{
	echo "$@"
	sleep 0.03
}

MyPrint "------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
MyPrint "二合一清理模块：功能一=定时清理缓存/空文件夹(key)；功能二=实时吃掉乱拉屎文件(忆雨)"
MyPrint "------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
MyPrint " "
MyPrint "(!) 安装说明："
MyPrint "- 安装完成重启后将默认删除/sdcard目录所有以.开头的文件夹/文件 以及其他无用文件夹"
MyPrint "- 先确认没有重要资料保存在/sdcard目录的以.开头的文件夹中 如果有请先备份后再安装刷入"
MyPrint " "
MyPrint "(?) 确认安装吗？(请选择)"
MyPrint "- 按音量键＋: 安装 √"
MyPrint "- 按音量键－: 退出 ×"
if [[ $(get_choose) == 0 ]]; then
	MyPrint "- 已选择安装"
	MyPrint " "
	if [[ -f /sdcard/Android/FUCK-XXX.conf ]]; then
		MyPrint "- 存在旧规则文件 是否保留原规则文件？(请选择)"
		MyPrint "- 按音量键＋: 保留"
		MyPrint "- 按音量键－: 替换"
		if [[ $(get_choose) == 1 ]]; then
			MyPrint "- 已选择替换备份原规则文件"
			cat /sdcard/Android/FUCK-XXX.conf > "/sdcard/Android/$(date "+%T")备份-FUCK-XXX.conf"
			MyPrint "- 已备份保存至/sdcard/Android/$(date "+%T")备份-FUCK-XXX.conf"
			rm -rf /sdcard/Android/FUCK-XXX.conf
			MyPrint "- 删除旧文件"
			cp -af $MODPATH/fuckshit/files/FUCK-XXX.conf /sdcard/Android/
			MyPrint "- 创建新文件"
			MyPrint " "
		else
			MyPrint "- 已选择保留原规则文件"
			MyPrint " "
		fi
	else
		MyPrint "- 创建规则文件至/sdcard/Android/ 重启后请打开该目录查看FUCK-XXX.conf"
		MyPrint " "
		cp -af $MODPATH/fuckshit/files/FUCK-XXX.conf /sdcard/Android/
	fi
	if [[ -d /data/adb/modules/clear_all_in_one_key/fuckshit/files/*/ ]]; then
		MyPrint "- 存在次数记录信息"
		cp -af /data/adb/modules/clear_all_in_one_key/fuckshit/files/*/ $MODPATH/fuckshit/files/
		MyPrint "- 复制信息"
		MyPrint " "
	fi
else
	abort "- 已选择退出"
fi
