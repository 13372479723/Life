#!/system/bin/sh

MODDIR=${0%/*}

PROCESS()
{
	ps -ef | grep "Clear_Script.sh" | grep -v grep | wc -l
}

while :
do
	if [[ ! -f $MODDIR/disable ]]; then
		if [[ $(PROCESS) -eq 0 ]]; then
			nohup sh $MODDIR/Clear_Script.sh &
		fi
	else
		if [[ $(PROCESS) -ne 0 ]]; then
			kill -9 $(ps -ef | grep Clear_Script.sh | grep -v grep | awk '{ print $2 }')
			# 注意：不再直接写 module.prop。停止状态记录到独立标记文件，
			# 模块描述统一由 merge_desc.sh 刷新，避免并发写导致 name/author 丢失或乱码。
			[[ $? == 0 ]] && echo "已手动停止运行 (重新打开则继续运行 无需重启)" > "$MODDIR/stopped"
		fi
	fi
	sleep 5
done