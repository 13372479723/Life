#!/system/bin/sh
###############################################################################
# 合并描述脚本（不改动任何原始清理程序）
# 作用：把两个清理脚本各自产生的统计读出来，拼成两段(空格连接)写进 module.prop
#   第一段(清理空文件夹/应用缓存)：取自 key 脚本写入的 log/total.log 最新一行
#   第二段(吃掉乱拉屎文件)：取自忆雨脚本写入的 fuckshit/files/<日期>/{file,dir}
# 原始脚本照常各跑各的，本脚本随后把 description 统一刷新为正确的两段。
###############################################################################
MODDIR=${0%/*}
PROP="$MODDIR/module.prop"

get_seg1() {
	local total="$MODDIR/log/total.log"
	local line=""
	if [ -f "$total" ]; then
		line=$(grep -v '^[[:space:]]*$' "$total" | tail -n 1)
	fi
	if [ -n "$line" ]; then
		echo "${line}日志在模块目录/log文件夹下，黑名单在模块目录/notclear.conf"
	else
		echo "清理空文件(夹)与应用缓存。日志在模块目录/log文件夹下，黑名单在模块目录/notclear.conf"
	fi
}

get_seg2() {
	local tmp="$MODDIR/fuckshit/files/$(date '+%Y-%m-%d')"
	local file=0
	local dir=0
	[ -f "$tmp/file" ] && file=$(cat "$tmp/file" 2>/dev/null)
	[ -f "$tmp/dir" ] && dir=$(cat "$tmp/dir" 2>/dev/null)
	[ -z "$file" ] && file=0
	[ -z "$dir" ] && dir=0
	echo "[ 今日已吃掉: ${file}个垃圾文件 ${dir}个垃圾文件夹 ]"
}

# 模块静态元信息(固定不变)。每次重写都用这份完整模板重建 prop，
# 仅 description 动态变化。这样即使上一次写入被中断导致 name/author 丢失，
# 下一轮(<=60s)会自动用模板补回，模块卡片不会再显示成 id。
MOD_ID="clear_all_in_one_key"
MOD_NAME="清理空文件夹缓存+吃掉乱拉屎的文件"
MOD_VERSION="1.0"
MOD_VERSIONCODE="1"
MOD_AUTHOR="key & 忆雨(原作者阿巴酱)"

# 用完整模板原子地重写 module.prop。先写临时文件再 mv，避免半截文件被读取。
write_prop() {
	local desc="$1"
	local tmpf="$PROP.tmp.$$"
	{
		printf 'id=%s\n' "$MOD_ID"
		printf 'name=%s\n' "$MOD_NAME"
		printf 'version=%s\n' "$MOD_VERSION"
		printf 'versionCode=%s\n' "$MOD_VERSIONCODE"
		printf 'author=%s\n' "$MOD_AUTHOR"
		printf 'description=%s\n' "$desc"
	} > "$tmpf" 2>/dev/null
	# 仅当临时文件确实写入了 name 行(写完整)才覆盖，进一步防止损坏。
	if grep -q '^name=' "$tmpf" 2>/dev/null; then
		mv -f "$tmpf" "$PROP"
	else
		rm -f "$tmpf" 2>/dev/null
	fi
}

while :; do
	seg1=$(get_seg1)
	seg2=$(get_seg2)
	# 显示顺序：先"吃掉垃圾"段(seg2)，再"清理缓存"段(seg1)
	# 写入字面的 \n 两个字符(由面具渲染为换行)，而非真实换行符
	desc="${seg2}\\n${seg1}"
	write_prop "$desc"
	sleep 60
done
