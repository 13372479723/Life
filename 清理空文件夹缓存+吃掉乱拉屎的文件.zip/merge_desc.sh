#!/system/bin/sh
###############################################################################
# 合并描述脚本（不改动任何原始清理程序）
# 作用：把两个清理脚本各自产生的统计读出来，拼成两段(空格连接)写进 module.prop
#   第一段(清理空文件夹/应用缓存)：取自 key 脚本写入的 log/total.log 最新一行
#   第二段(吃掉乱拉屎文件)：取自忆雨脚本写入的 fuckshit/files/<日期>/{file,dir}
# 原始脚本照常各跑各的，本脚本随后把 description 统一刷新为正确的两段。
###############################################################################
MODDIR=${0%/*}
PROP="$MODDIR/module.prop"

get_seg1() {
	local total="$MODDIR/log/total.log"
	local line=""
	if [ -f "$total" ]; then
		line=$(grep -v '^[[:space:]]*$' "$total" | tail -n 1)
	fi
	if [ -n "$line" ]; then
		echo "${line}日志在模块目录/log文件夹下，黑名单在模块目录/notclear.conf"
	else
		echo "清理空文件(夹)与应用缓存。日志在模块目录/log文件夹下，黑名单在模块目录/notclear.conf"
	fi
}

get_seg2() {
	local tmp="$MODDIR/fuckshit/files/$(date '+%Y-%m-%d')"
	local file=0
	local dir=0
	[ -f "$tmp/file" ] && file=$(cat "$tmp/file" 2>/dev/null)
	[ -f "$tmp/dir" ] && dir=$(cat "$tmp/dir" 2>/dev/null)
	[ -z "$file" ] && file=0
	[ -z "$dir" ] && dir=0
	echo "[ 今日已吃掉: ${file}个垃圾文件 ${dir}个垃圾文件夹 ]"
}

# 把除 description 外的其它属性行原样保留，重写 description 为两段(\n换行)
write_prop() {
	local desc="$1"
	local tmpf="$PROP.tmp"
	grep -v '^description=' "$PROP" > "$tmpf" 2>/dev/null
	printf 'description=%s\n' "$desc" >> "$tmpf"
	mv -f "$tmpf" "$PROP"
}

while :; do
	seg1=$(get_seg1)
	seg2=$(get_seg2)
	# 写入字面的 \n 两个字符(由面具渲染为换行)，而非真实换行符
	desc="${seg1}\\n${seg2}"
	write_prop "$desc"
	sleep 60
done
