#!/system/bin/sh
MODDIR=${0%/*}
BUSYBOXDIR=$MODDIR/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

##############################################################################
# 功能一：清理空文件夹/应用缓存(作者 key) —— 原 service.sh 逻辑(crond 定时)
##############################################################################
test -e $MODDIR/mod && {
	chmod -R 777 $MODDIR/mod
	until $(dumpsys deviceidle get screen) ;do
		sleep 5
	done
	for i in $MODDIR/mod/*.sh ;do
		$i 2> /dev/null
	done
}

test -e $MODDIR/crond && {
chmod -R 777 $MODDIR/crond
sh $MODDIR/crond/setupcrond.sh
}

##############################################################################
# 功能二：吃掉乱拉屎的文件/文件夹(作者 忆雨) —— 原 service.sh 逻辑(常驻实时)
# 原模块2脚本放在子目录 fuckshit/ 下，脚本内部以 $MODDIR(=fuckshit) 引用
# 同目录文件并读写 $MODDIR/module.prop。这里给 fuckshit/ 一个独立的占位
# module.prop(不指向真实文件)，让忆雨脚本照常写入而不污染真实描述；真实
# 描述统一由下方 merge_desc.sh 拼接两段统计后写入。原始脚本均未改动。
##############################################################################
test -d $MODDIR/fuckshit && {
	chmod -R 777 $MODDIR/fuckshit
	rm -f $MODDIR/fuckshit/module.prop 2>/dev/null
	echo "description=" > $MODDIR/fuckshit/module.prop
	nohup sh $MODDIR/fuckshit/service_fuckshit.sh >/dev/null 2>&1 &
}

##############################################################################
# 合并描述：把上面两套清理脚本各自的统计拼成两段(空格连接)写进 module.prop
# 不改动任何原始清理程序，仅负责刷新模块卡片显示的描述文字。
##############################################################################
test -e $MODDIR/merge_desc.sh && {
	chmod 0755 $MODDIR/merge_desc.sh
	nohup sh $MODDIR/merge_desc.sh >/dev/null 2>&1 &
}
