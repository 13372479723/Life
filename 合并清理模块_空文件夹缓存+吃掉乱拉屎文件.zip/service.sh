#!/system/bin/sh
MODDIR=${0%/*}
BUSYBOXDIR=$MODDIR/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH

##############################################################################
# 功能一：清理空文件夹/应用缓存(作者 key) —— 原 service.sh 逻辑(crond 定时)
##############################################################################
test -e $MODDIR/mod && {
	chmod -R 777 $MODDIR/mod
	until $(dumpsys deviceidle get screen) ;do
		sleep 5
	done
	for i in $MODDIR/mod/*.sh ;do
		$i 2> /dev/null
	done
}

test -e $MODDIR/crond && {
chmod -R 777 $MODDIR/crond
sh $MODDIR/crond/setupcrond.sh
}

##############################################################################
# 功能二：吃掉乱拉屎的文件/文件夹(作者 忆雨) —— 原 service.sh 逻辑(常驻实时)
# 原模块2脚本放在子目录 fuckshit/ 下，脚本内部以 $MODDIR(=fuckshit) 引用
# 同目录文件并读写 $MODDIR/module.prop，因此这里让 fuckshit/module.prop
# 指向真实 module.prop(软链接)，从而不改动原始脚本即可正常工作。
##############################################################################
test -d $MODDIR/fuckshit && {
	chmod -R 777 $MODDIR/fuckshit
	ln -sf $MODDIR/module.prop $MODDIR/fuckshit/module.prop 2>/dev/null
	nohup sh $MODDIR/fuckshit/service_fuckshit.sh >/dev/null 2>&1 &
}
